# Universal Dragon Ecosystem

Universal Dragon lives.
NOVA thinks.
EVE controls.
UDOS displays.
Pi5 runs.
GitHub stores/builds.
Cloudflare routes.
Aslam builds.

NOVA is not the whole ecosystem.
NOVA is one core brain/language part inside Universal Dragon.
